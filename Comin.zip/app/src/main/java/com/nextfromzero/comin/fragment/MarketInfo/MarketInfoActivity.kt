package com.nextfromzero.comin.fragment.MarketInfo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import com.nextfromzero.comin.R
import kotlinx.android.synthetic.main.activity_market_info.*

class MarketInfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_market_info)
        figure_1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 25f)
        figure_2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
        figure_3.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)

        supportFragmentManager.beginTransaction().replace(R.id.fragment_area, ContentFragment()).commit()

        figure_1.setOnClickListener {
            figure_1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 25f)
            figure_2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
            figure_3.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
            supportFragmentManager.beginTransaction().replace(R.id.fragment_area, ContentFragment()).commit()
        }
        figure_2.setOnClickListener {
            figure_1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
            figure_2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 25f)
            figure_3.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
            supportFragmentManager.beginTransaction().replace(R.id.fragment_area, InfoFragment()).commit()
        }
        figure_3.setOnClickListener {
            figure_1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
            figure_2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
            figure_3.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 25f)
            supportFragmentManager.beginTransaction().replace(R.id.fragment_area, ReviewFragment()).commit()
        }
    }
}
