package com.nextfromzero.comin.fragment

data class ContentListModel(
    var image : String,
    var title : String,
    var number : Int,
    var category : String
)